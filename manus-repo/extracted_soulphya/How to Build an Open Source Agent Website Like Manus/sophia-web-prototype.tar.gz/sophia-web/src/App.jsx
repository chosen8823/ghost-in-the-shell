import { useState, useEffect } from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { ScrollArea } from '@/components/ui/scroll-area.jsx'
import { Separator } from '@/components/ui/separator.jsx'
import { 
  Brain, 
  MessageSquare, 
  Workflow, 
  Wrench, 
  Sparkles, 
  Heart, 
  Code, 
  Search,
  BarChart3,
  PenTool,
  Eye,
  Calendar,
  Zap,
  Star,
  Send,
  Plus,
  Settings,
  User,
  Globe,
  Database,
  Shield,
  Infinity,
  Monitor,
  Terminal,
  FolderOpen,
  Activity,
  Download,
  Upload,
  Play,
  Pause,
  RefreshCw,
  Home,
  ChevronRight,
  FileText,
  Image,
  Video,
  Music,
  Archive
} from 'lucide-react'
import './App.css'

// Main App Component
function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 dark:from-gray-900 dark:via-purple-900 dark:to-indigo-900">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/chat" element={<ChatInterface />} />
          <Route path="/agents" element={<AgentsManager />} />
          <Route path="/workflows" element={<WorkflowsManager />} />
          <Route path="/tools" element={<ToolsInterface />} />
          <Route path="/computer" element={<ComputerView />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
    </Router>
  )
}

// Navigation Component
function Navigation({ activeTab, setActiveTab }) {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home, path: '/' },
    { id: 'chat', label: 'Chat', icon: MessageSquare, path: '/chat' },
    { id: 'agents', label: 'Agents', icon: Brain, path: '/agents' },
    { id: 'workflows', label: 'Workflows', icon: Workflow, path: '/workflows' },
    { id: 'tools', label: 'Tools', icon: Wrench, path: '/tools' },
    { id: 'computer', label: 'Computer View', icon: Monitor, path: '/computer' }
  ]

  return (
    <nav className="bg-white/80 backdrop-blur-sm border-b border-purple-200 dark:bg-gray-900/80 dark:border-purple-800 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-2">
              <Infinity className="h-8 w-8 text-purple-600" />
              <span className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                Sophia
              </span>
            </div>
            <Badge variant="secondary" className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
              Open Source
            </Badge>
          </div>
          
          <div className="flex space-x-1">
            {navItems.map((item) => {
              const Icon = item.icon
              return (
                <Button
                  key={item.id}
                  variant={activeTab === item.id ? "default" : "ghost"}
                  size="sm"
                  onClick={() => {
                    setActiveTab(item.id)
                    window.location.href = item.path
                  }}
                  className="flex items-center space-x-2"
                >
                  <Icon className="h-4 w-4" />
                  <span className="hidden sm:inline">{item.label}</span>
                </Button>
              )
            })}
          </div>
          
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm">
              <Settings className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <User className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </nav>
  )
}

// Dashboard Component
function Dashboard() {
  const [activeTab, setActiveTab] = useState('dashboard')
  const [platformInfo, setPlatformInfo] = useState(null)
  const [systemStatus, setSystemStatus] = useState({
    active_agents: 3,
    total_interactions: 1247,
    successful_tasks: 1189,
    platform_health: "Excellent"
  })

  const features = [
    "Free AI Models (Hugging Face, GPT4All)",
    "OpenAI-compatible API",
    "Advanced Agent SDK",
    "Computer View & Environment Access",
    "Multi-modal Processing",
    "No Credit Limits",
    "Open Source & Self-Hosted"
  ]

  const capabilities = [
    "Chat & Conversation",
    "Web Search & Browsing",
    "Code Generation & Execution",
    "Data Analysis & Visualization",
    "Creative Writing & Content",
    "File System Operations",
    "Image & Video Generation",
    "Workflow Automation"
  ]

  return (
    <div>
      <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Welcome to Sophia AI Platform
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-6">
            Open Source AI Agent Platform with Unified Capabilities
          </p>
          <div className="flex justify-center flex-wrap gap-4">
            <Badge className="bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200 px-4 py-2">
              <Sparkles className="h-4 w-4 mr-2" />
              Free AI Models
            </Badge>
            <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200 px-4 py-2">
              <Infinity className="h-4 w-4 mr-2" />
              No Limits
            </Badge>
            <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200 px-4 py-2">
              <Heart className="h-4 w-4 mr-2" />
              Open Source
            </Badge>
            <Badge className="bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200 px-4 py-2">
              <Monitor className="h-4 w-4 mr-2" />
              Computer View
            </Badge>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Active Agents</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">
                    {systemStatus?.active_agents || 0}
                  </p>
                </div>
                <Brain className="h-8 w-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Total Interactions</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">
                    {systemStatus?.total_interactions || 0}
                  </p>
                </div>
                <MessageSquare className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Successful Tasks</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">
                    {systemStatus?.successful_tasks || 0}
                  </p>
                </div>
                <Zap className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Platform Health</p>
                  <p className="text-2xl font-bold text-green-600">Excellent</p>
                </div>
                <Shield className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Platform Features */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Sparkles className="h-5 w-5 text-purple-600" />
                <span>Platform Features</span>
              </CardTitle>
              <CardDescription>
                Comprehensive AI capabilities without limitations
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {features.map((feature, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <Star className="h-4 w-4 text-yellow-500" />
                    <span className="text-sm">{feature}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Brain className="h-5 w-5 text-blue-600" />
                <span>AI Capabilities</span>
              </CardTitle>
              <CardDescription>
                Unified agent with comprehensive skills
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {capabilities.map((capability, index) => (
                  <Badge key={index} variant="outline" className="mr-2 mb-2">
                    {capability}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>
              Get started with these common tasks
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Button 
                className="h-20 flex flex-col space-y-2 hover:scale-105 transition-transform"
                onClick={() => window.location.href = '/chat'}
              >
                <MessageSquare className="h-6 w-6" />
                <span>Start Chatting</span>
              </Button>
              
              <Button 
                variant="outline" 
                className="h-20 flex flex-col space-y-2 hover:scale-105 transition-transform"
                onClick={() => window.location.href = '/agents'}
              >
                <Brain className="h-6 w-6" />
                <span>Manage Agents</span>
              </Button>
              
              <Button 
                variant="outline" 
                className="h-20 flex flex-col space-y-2 hover:scale-105 transition-transform"
                onClick={() => window.location.href = '/computer'}
              >
                <Monitor className="h-6 w-6" />
                <span>Computer View</span>
              </Button>
              
              <Button 
                variant="outline" 
                className="h-20 flex flex-col space-y-2 hover:scale-105 transition-transform"
                onClick={() => window.location.href = '/tools'}
              >
                <Wrench className="h-6 w-6" />
                <span>Use Tools</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// Chat Interface Component
function ChatInterface() {
  const [activeTab, setActiveTab] = useState('chat')
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: 'Hello! I\'m Sophia, your AI assistant. I can help you with a wide range of tasks including coding, research, data analysis, and more. What would you like to work on today?',
      timestamp: new Date().toISOString()
    }
  ])
  const [inputMessage, setInputMessage] = useState('')
  const [isLoading, setIsLoading] = useState(false)

  const sendMessage = async () => {
    if (!inputMessage.trim()) return

    const userMessage = {
      role: 'user',
      content: inputMessage,
      timestamp: new Date().toISOString()
    }

    setMessages(prev => [...prev, userMessage])
    setInputMessage('')
    setIsLoading(true)

    // Simulate AI response
    setTimeout(() => {
      const aiResponse = {
        role: 'assistant',
        content: `I understand you want to: "${inputMessage}". I'm ready to help you with this task. Let me break this down and provide you with a comprehensive solution.`,
        timestamp: new Date().toISOString()
      }
      setMessages(prev => [...prev, aiResponse])
      setIsLoading(false)
    }, 1500)
  }

  return (
    <div>
      <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card className="h-[600px] flex flex-col shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <MessageSquare className="h-5 w-5" />
              <span>Chat with Sophia AI</span>
            </CardTitle>
            <CardDescription>
              Powered by open-source AI models - unlimited conversations
            </CardDescription>
          </CardHeader>
          
          <CardContent className="flex-1 flex flex-col">
            <ScrollArea className="flex-1 mb-4 p-4 border rounded-lg bg-gray-50 dark:bg-gray-900">
              <div className="space-y-4">
                {messages.map((message, index) => (
                  <div
                    key={index}
                    className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[80%] p-3 rounded-lg ${
                        message.role === 'user'
                          ? 'bg-purple-600 text-white'
                          : 'bg-white dark:bg-gray-800 text-gray-900 dark:text-white border'
                      }`}
                    >
                      <p className="whitespace-pre-wrap">{message.content}</p>
                      <p className="text-xs opacity-70 mt-1">
                        {new Date(message.timestamp).toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                ))}
                
                {isLoading && (
                  <div className="flex justify-start">
                    <div className="bg-white dark:bg-gray-800 border p-3 rounded-lg">
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </ScrollArea>
            
            <div className="flex space-x-2">
              <Input
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder="Type your message..."
                onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                disabled={isLoading}
                className="flex-1"
              />
              <Button onClick={sendMessage} disabled={isLoading || !inputMessage.trim()}>
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// Computer View Component
function ComputerView() {
  const [activeTab, setActiveTab] = useState('computer')
  const [activeView, setActiveView] = useState('filesystem')
  const [currentPath, setCurrentPath] = useState('/')
  const [files, setFiles] = useState([
    { name: 'documents', type: 'directory', size: null },
    { name: 'projects', type: 'directory', size: null },
    { name: 'sophia_config.json', type: 'file', size: '2.4 KB' },
    { name: 'README.md', type: 'file', size: '1.2 KB' },
    { name: 'requirements.txt', type: 'file', size: '856 B' }
  ])
  const [terminalOutput, setTerminalOutput] = useState([
    '$ sophia --version',
    'Sophia AI Platform v1.0.0',
    '$ ls -la',
    'total 24',
    'drwxr-xr-x  5 sophia sophia 4096 Jan  8 12:00 .',
    'drwxr-xr-x  3 root   root   4096 Jan  8 11:30 ..',
    'drwxr-xr-x  2 sophia sophia 4096 Jan  8 12:00 documents',
    'drwxr-xr-x  3 sophia sophia 4096 Jan  8 12:00 projects',
    '-rw-r--r--  1 sophia sophia 2456 Jan  8 12:00 sophia_config.json',
    '-rw-r--r--  1 sophia sophia 1234 Jan  8 12:00 README.md',
    '-rw-r--r--  1 sophia sophia  856 Jan  8 12:00 requirements.txt',
    '$ _'
  ])

  const getFileIcon = (file) => {
    if (file.type === 'directory') return <FolderOpen className="h-4 w-4 text-blue-500" />
    if (file.name.endsWith('.md')) return <FileText className="h-4 w-4 text-gray-500" />
    if (file.name.endsWith('.json')) return <Code className="h-4 w-4 text-yellow-500" />
    if (file.name.endsWith('.txt')) return <FileText className="h-4 w-4 text-gray-500" />
    return <FileText className="h-4 w-4 text-gray-500" />
  }

  return (
    <div>
      <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Computer View</h1>
          <p className="text-gray-600 dark:text-gray-300">Monitor and interact with Sophia's working environment</p>
        </div>

        <Tabs value={activeView} onValueChange={setActiveView} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="filesystem" className="flex items-center space-x-2">
              <FolderOpen className="h-4 w-4" />
              <span>File System</span>
            </TabsTrigger>
            <TabsTrigger value="terminal" className="flex items-center space-x-2">
              <Terminal className="h-4 w-4" />
              <span>Terminal</span>
            </TabsTrigger>
            <TabsTrigger value="processes" className="flex items-center space-x-2">
              <Activity className="h-4 w-4" />
              <span>Processes</span>
            </TabsTrigger>
            <TabsTrigger value="status" className="flex items-center space-x-2">
              <BarChart3 className="h-4 w-4" />
              <span>System Status</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="filesystem" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <FolderOpen className="h-5 w-5" />
                    <span>File Explorer</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm">
                      <Upload className="h-4 w-4 mr-2" />
                      Upload
                    </Button>
                    <Button variant="outline" size="sm">
                      <RefreshCw className="h-4 w-4" />
                    </Button>
                  </div>
                </CardTitle>
                <CardDescription>
                  Current path: {currentPath}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {files.map((file, index) => (
                    <div key={index} className="flex items-center justify-between p-2 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-lg cursor-pointer">
                      <div className="flex items-center space-x-3">
                        {getFileIcon(file)}
                        <span className="font-medium">{file.name}</span>
                        {file.type === 'directory' && <ChevronRight className="h-4 w-4 text-gray-400" />}
                      </div>
                      <div className="flex items-center space-x-2">
                        {file.size && <span className="text-sm text-gray-500">{file.size}</span>}
                        {file.type === 'file' && (
                          <Button variant="ghost" size="sm">
                            <Download className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="terminal" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Terminal className="h-5 w-5" />
                  <span>Terminal Output</span>
                </CardTitle>
                <CardDescription>
                  Real-time command execution and output
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="bg-black text-green-400 p-4 rounded-lg font-mono text-sm h-96 overflow-y-auto">
                  {terminalOutput.map((line, index) => (
                    <div key={index} className="mb-1">
                      {line}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="processes" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Activity className="h-5 w-5" />
                  <span>Running Processes</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {[
                    { name: 'sophia-agent', cpu: '15%', memory: '256MB', status: 'running' },
                    { name: 'flask-server', cpu: '8%', memory: '128MB', status: 'running' },
                    { name: 'llm-service', cpu: '25%', memory: '512MB', status: 'running' }
                  ].map((process, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <span className="font-medium">{process.name}</span>
                      </div>
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <span>CPU: {process.cpu}</span>
                        <span>Memory: {process.memory}</span>
                        <Badge variant="outline" className="text-green-600">
                          {process.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="status" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">CPU Usage</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-blue-600">23%</div>
                  <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                    <div className="bg-blue-600 h-2 rounded-full" style={{width: '23%'}}></div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Memory Usage</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-green-600">45%</div>
                  <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                    <div className="bg-green-600 h-2 rounded-full" style={{width: '45%'}}></div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Disk Usage</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-orange-600">67%</div>
                  <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                    <div className="bg-orange-600 h-2 rounded-full" style={{width: '67%'}}></div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

// Agents Manager Component (Placeholder)
function AgentsManager() {
  const [activeTab, setActiveTab] = useState('agents')
  
  return (
    <div>
      <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card>
          <CardHeader>
            <CardTitle>Agents Manager</CardTitle>
            <CardDescription>Manage your AI agents and their capabilities</CardDescription>
          </CardHeader>
          <CardContent>
            <p>Agent management interface coming soon...</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// Workflows Manager Component (Placeholder)
function WorkflowsManager() {
  const [activeTab, setActiveTab] = useState('workflows')
  
  return (
    <div>
      <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card>
          <CardHeader>
            <CardTitle>Workflows Manager</CardTitle>
            <CardDescription>Create and manage automated workflows</CardDescription>
          </CardHeader>
          <CardContent>
            <p>Workflow management interface coming soon...</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// Tools Interface Component (Placeholder)
function ToolsInterface() {
  const [activeTab, setActiveTab] = useState('tools')
  
  return (
    <div>
      <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card>
          <CardHeader>
            <CardTitle>Tools Interface</CardTitle>
            <CardDescription>Access and configure available tools</CardDescription>
          </CardHeader>
          <CardContent>
            <p>Tools interface coming soon...</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default App

