chmod +x cloud_setup.sh
./cloud_setup.sh
