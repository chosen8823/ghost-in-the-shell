export const GCP_CONFIG = {
  projectId: 'blissful-epoch-467811-i3',
  storageBucket: 'cloud-ai-platform-52e5c355-bbc0-4945-8c97-750e83f7f058',
  serviceAccount: '287875100221-compute@developer.gserviceaccount.com'
};